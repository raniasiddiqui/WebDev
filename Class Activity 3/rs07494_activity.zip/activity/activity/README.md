# React Todo App Activity (40 minutes)

Build a Todo application to practice React fundamentals. The boilerplate code includes a working form input - you'll implement the todo management functionality.

## What's Provided
- Form with input field and submit button
- Input state management and form handling
- Form submission that logs todo text to console

## Your Tasks

### 1. Add Todo State (5 mins)
- Create a todos state variable using useState
- It should store an array of todo objects
- Each todo needs: id (from Date.now()), text, and completed status

### 2. Complete the addTodo Function (10 mins)
The form submission already handles:
- Preventing default
- Input validation
- Console logging
- Clearing input

You need to:
- Create a new todo object with the required properties
- Add it to the todos array using setTodos

### 3. Render Todo List (10 mins)
Inside the provided `<ul>`:
- Map through the todos array
- For each todo, render:
  - A checkbox for completion status
  - The todo text
- Remember to add a key prop to list items

### 4. Implement Toggle Function (10 mins)
In the toggleTodo function:
- Use setTodos to update the todos array
- Find the todo with matching id
- Toggle its completed status
- Keep other todos unchanged

### 5. Add Remaining Count (5 mins)
In the remainingTodos function:
- Count todos that aren't completed
- Display the count in the designated div

## Testing Your Work
- Add a few todos - they should appear in the list
- Toggle checkboxes - completion status should change
- Remaining count should update when toggling todos
- Form should clear after adding a todo
- Empty todos shouldn't be added

## Bonus Challenges
If you finish early:
- Add delete functionality
- Style completed todos differently
- Add filters (All/Active/Completed)

## Tips
- Check the console for errors
- Test each feature as you build it
ongratulation message isn't showing, check your useEffect dependencies

## Grading
Total Points: 100

- Todo State Implementation (20 points)
  - Correct useState initialization (10)
  - Proper todo object structure (10)

- Add Todo Functionality (25 points)
  - Correct todo object creation (10)
  - Proper state update with setTodos (10)
  - Input clearing after submission (5)

- Todo List Rendering (25 points)
  - Successful mapping of todos (10)
  - Checkbox implementation (5)
  - Todo text display (5)
  - Proper key usage (5)

- Toggle Functionality (20 points)
  - Correct todo identification (5)
  - Proper state update (10)
  - Toggle status working (5)

- Remaining Count (10 points)
  - Accurate count calculation (5)
  - Display implementation (5)

Bonus Points (up to 15 extra points):
- Delete functionality (+5)
- Completed todo styling (+5)
- Filter implementation (+5)

Good luck! 🎬 ✨
