import { useState } from 'react'

function App() {
  // TODO: Create state variables for:
  // 1. todos array: [{id, text, completed}]
  const [todos, setTodos] = useState([])
  const [inputValue, setInputValue] = useState('')
  const addTodo = (e) => {
    e.preventDefault()
    if (!inputValue.trim()) return

    const newTodo = {
      id: Date.now(),
      text: inputValue,
      completed: false
    }
    setTodos([...todos, newTodo])
    setInputValue('')


    
    // This function already:
    // ✓ Prevents default form submission (e.preventDefault())
    // ✓ Validates empty input (!inputValue.trim())
    // ✓ Logs the todo text (console.log)
    // ✓ Clears the input (setInputValue(''))
    
    // Your task:
    // 1. Create a todo object with:
    //    - id: use Date.now()
    //    - text: use inputValue
    //    - completed: set to false
    // 2. Add this new todo to todos array using setTodos
    //    Hint: use spread operator [...todos, newTodo]
    e.preventDefault()
    if (!inputValue.trim()) return
    console.log('New todo:', inputValue)
    setInputValue('')
  }

  // eslint-disable-next-line no-unused-vars
  const toggleTodo = (id) => {
    setTodos(
      todos.map(todo => {
        if (todo.id === id) {
          return {
            ...todo,
            completed: !todo.completed
          }
        }
        return todo
      })
    )
    // Your task:
    // 1. Use setTodos to update todos array
    // 2. Map through current todos
    // 3. When todo.id matches id parameter:
    //    - Return a new object with completed toggled
    // 4. Otherwise return todo unchanged
  }

  // eslint-disable-next-line no-unused-vars
  const remainingTodos = () => {
    return todos.filter(todo => !todo.completed).length
    // Your task:
    // 1. Filter todos array to get incomplete todos
    //    Hint: todo => !todo.completed
    // 2. Return the length of filtered array
  }

  return (
    <div style={{ textAlign: 'center', maxWidth: '500px', margin: '0 auto' }}>
      <h1>Todo App</h1>
      
      <form onSubmit={addTodo}>
        <input 
          type="text"
          placeholder="Add a new todo"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
        <button type="submit">Add</button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0 }}>
      {todos.map(todo => (
        <li key={todo.id}>
          <input 
            type="checkbox" 
            checked={todo.completed} 
            onChange={() => toggleTodo(todo.id)} 
          />
          {todo.text}
        </li>
      ))}
      </ul>

      <div>
        Remaining todos: {remainingTodos()}
      </div>
    </div>
  )
}

export default App
